/*
 * Copyright (C) 2018 NTT DATA Corporation.
 */
'use strict';

const express     = require('express');
const router      = express.Router();

const errorjs     = require('./../../../express/lib/error.js');

const filesHelper   = require('./helper/filesHelper.js');
const multerHelper  = require('./../helper/multerHelper.js');

const fileUploadService = require('./../service/fileUploadService.js');
const fileDownloadService = require('./../service/fileDownloadService.js');

const logger      = require('./../../../express/config/logger.js');
const loggerTitle ='[files]';

/**
 * 添付ファイル取得
 */
router.get('/:id/:region/:bucket/:companyCode/:key', async (req, res, next) => {
  logger.api.info  (`${loggerTitle}[get] start`);
  logger.api.debug (`${loggerTitle}[get]` , req.params );

  try {
    filesHelper.validatorGet( req, res );

    const result = await fileDownloadService.execute( {
      'docId'       : req.params.id ,
      'region'      : req.params.region ,
      'bucket'      : req.params.bucket ,
      'companyCode' : req.params.companyCode ,
      'key'         : req.params.key } );

    res.attachment( result.originalname );
    result.s3Stream.pipe(res);
    result.s3Stream.on('error', (error) => {
      logger.api.error (`${loggerTitle}[get] stream error:` , error );
      res.removeHeader('Content-Type');
      res.removeHeader('Content-Disposition');
      next( errorjs.createError('TPSystemErrorInternalServerError') );
      return;
    });
  } catch (error) {
    if( errorjs.isBussinessError(error.name) ) {
      logger.api.debug(`${loggerTitle}[get]` , error );
    }else {
      logger.api.error(`${loggerTitle}[get]` , error );
    }
    next(error);
  }
});

/**
 * 添付ファイル登録
 */
/*
router.post('/', multerHelper.uploadFile , async (req, res, next) => {
  logger.api.info  (`${loggerTitle}[post] start`);
  logger.api.debug (`${loggerTitle}[post]` , req.body , req.files );

  try {

    filesHelper.validatorPost( req, res );
    const result = await fileUploadService.execute( { 'files' : req.files } );

    res.send(result);
  } catch (error) {
    if( errorjs.isBussinessError(error.name) ) {
      logger.api.debug(`${loggerTitle}[post]` , error );
    }else {
      logger.api.error(`${loggerTitle}[post]` , error );
    }
    next(error);
  }

});
*/
router.post('/', async (req, res, next) => {
 console.log('aaaa');
 console.log(req.files);
 console.log('aaaa');
 res.send('{"region":"ap-northeast-1","bucket":"dev-tradeplatform-prototype","key":"U0000000004/19175924b0992310fe87f58ce24626ce6f12bcf5f892f24974c80fe40fd3e2e7","originalname":"aaaaa.txt"}');

});

module.exports = router;
